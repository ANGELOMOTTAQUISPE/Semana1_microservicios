package businessbanking.service;

import businessbanking.model.Account;

public interface IAccountService extends ICRUD<Account, String>{
}
